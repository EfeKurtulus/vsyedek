﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace SQLNTP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection("Data Source=LAB8-5;Initial Catalog=VT_TEMRIN;Integrated Security=True");
            SqlCommand komut = new SqlCommand();
            komut.Connection = baglanti;            
            baglanti.Open();
            komut.Parameters.Clear();
            komut.CommandText="insert into TblOgrenciler(O_TC_KIMLIK,O_AD,O_SOYAD,O_SIFRE,O_E_MAIL,O_BOLUM,O_SINIF) values(@tc,@ad,@sd,@sf,@ml,@bl,@snf)";
            komut.Parameters.AddWithValue("@tc", textBox1.Text);
            komut.Parameters.AddWithValue("@ad", textBox2.Text);
            komut.Parameters.AddWithValue("@sd", textBox3.Text);
            komut.Parameters.AddWithValue("@sf", textBox4.Text);
            komut.Parameters.AddWithValue("@ml", textBox5.Text);
            komut.Parameters.AddWithValue("@bl", textBox6.Text);
            komut.Parameters.AddWithValue("@snf", textBox7.Text);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Kayıt Eklendi");
        }
    }
}
